NEXUS REQUIRED MERITS CALCULATOR

Formula:
% of Highest Historical Power = Required Merits

Example:
120,000,000 HHP x 5% = 6,000,000 required merits

GitHub Pages Directions:

1. Go to github.com and sign in or create a free account.

2. Click the + button in the top right, then click New repository.

3. Repository name:
   server102-merits

4. Set the repository to Public.

5. Click Create repository.

6. Click uploading an existing file.

7. Upload the index.html file from this folder.

8. Click Commit changes.

9. Go to Settings.

10. In the left menu, click Pages.

11. Under Build and deployment:
    Source: Deploy from a branch
    Branch: main
    Folder: /root

12. Click Save.

13. Wait 1-3 minutes.

14. Your calculator link should be:
    https://YOUR-GITHUB-USERNAME.github.io/server102-merits/

15. Paste that link in Discord.

Important:
Do not upload the HTML file directly to Discord.
Discord will not run the calculator script from an uploaded HTML file.
It needs to be hosted as a webpage link.
